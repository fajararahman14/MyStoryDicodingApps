package com.fajar.mystorydicodingapps.entity

data class EntityUser(
    val name : String,
    val token : String,
    val isLogin : Boolean
)